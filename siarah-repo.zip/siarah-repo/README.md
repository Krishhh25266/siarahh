# Siarah

Siarah is a static, browser-based preview for a made-to-order corset collection. It uses HTML, CSS, vanilla JavaScript, JSON catalogue data, and a Python build script. It is a public demonstration, not a transactional storefront.

## What's included

- `src/template.html` — site layout, styles, hash routes, customiser, bag, and preview checkout.
- `data/designs.json` and `data/prints.json` — catalogue content and image paths.
- `assets/` — design and print artwork.
- `scripts/build.py` — embeds catalogue artwork, copies local corset sale photos and optional homepage media, and writes `dist/index.html`.
- `docs/API_CONTRACT.md` — proposed backend and payment handover contract; it is not implemented by this frontend.
- `vercel.json` — Vercel build and static output settings.

## Build and preview

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/build.py
python3 -m http.server --directory dist 8000
```

Open `http://localhost:8000/`. The generated `dist/` directory is ignored by Git because Vercel regenerates it during deployment. Do not edit `dist/index.html` by hand.

To replace the temporary homepage visuals, add `assets/homepage/campaign.mp4` (or `.webm`) and `assets/homepage/campaign-photo.jpg` (also `.jpeg`, `.png`, or `.webp` are supported), then rebuild. The script copies supplied media into `dist/homepage-media/` for Vercel.

The demonstration sale listing uses local corset-fashion photos in `assets/sale-corsets/`. The images are from [Pexels](https://www.pexels.com/) and are covered by the [Pexels license](https://www.pexels.com/license/): [black corset dress](https://www.pexels.com/photo/stylish-young-woman-posing-at-nighttime-city-street-30141994/) by PHOTO MY nguyen, [black lace-up corset](https://www.pexels.com/photo/woman-in-black-corset-top-19329546/) by Paul Uchechukwu, [white lace corset](https://www.pexels.com/photo/brunette-woman-in-white-lace-corset-top-touching-her-pearl-necklace-18424744/) by Beyzaa Yurtkuran, [off-shoulder corset dress](https://www.pexels.com/photo/fashionable-woman-in-urban-setting-against-window-30214720/) by David Kouakou, and [corset gown](https://www.pexels.com/photo/brunette-woman-posing-in-dress-18149120/) by Yash Singh.

## Demo limits

- The bag and customiser use browser storage. There is no order API, payment gateway, customer account, or newsletter storage.
- Step 2 of the customiser selects one of four fabric categories. Step 3 shows that category's design choices: the existing print cards for Linen Prints and Chanderi Prints, 12 reference colour designs for Linen Plains, or five for Lace. The selected design is retained through review and the browser-stored bag. The texture cards are individual crops of the fabric references supplied for this preview.
- Checkout is a preview only. It does not submit an order or payment, and the bag remains unchanged. Checkout fields stay in the current page and are not sent to a server or saved by the site.
- `.env.example` lists future backend placeholders only; this static preview does not read those variables.
- Satin remains unavailable in the customiser. Shipping, GST, dispatch estimates, support details, and the returns policy still need owner confirmation.
- Account and About pages are informational placeholders. The homepage video and photo panels currently show temporary corset illustrations until campaign media is supplied.

Do not treat this project as ready to accept customer orders or real payments until an approved backend, payment integration, customer-facing policies, and support details are in place.

## Vercel

The root `vercel.json` selects Vercel's **Other** preset, creates a project-local Python virtual environment, installs the dependency there, runs `scripts/build.py` with that environment, and serves `dist/`. Deploy from the repository root so the source, assets, build script, and requirements file are available. The generated site embeds catalogue artwork, copies optional homepage media into `dist/`, and uses hash-based routes, so it does not need a custom domain or route rewrite.

To deploy, import the repository into Vercel and deploy from the repository root. The build and output settings are read from `vercel.json`; no frontend environment variables are required. Verify the Vercel preview deployment before promoting it to production. Vercel also adds baseline security response headers configured in `vercel.json`.

This deployment is a static product preview only. Do not accept customer orders or payments until the backend, payment integration, confirmed policies, and support details described above are implemented.

## Catalogue and pricing

The current preview contains 26 designs and 18 prints. Prices are displayed from the frontend's `PRICE` object for demonstration only; a production server must validate catalogue selections and calculate all prices itself. Do not change product names, IDs, prices, or measurement limits without owner approval.

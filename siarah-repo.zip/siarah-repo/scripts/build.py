"""Builds dist/index.html and copies optional homepage media into dist/.

Usage (from the repo root):  python3 scripts/build.py
Needs: Python 3 and Pillow  (pip install -r requirements.txt)
"""
import base64, io, json, shutil
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent

def uri(path, width, quality):
    im = Image.open(path).convert("RGB")
    im = im.resize((width, int(im.height * width / im.width)), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=quality, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()

designs = json.loads((ROOT / "data/designs.json").read_text(encoding="utf-8"))["designs"]
prints = json.loads((ROOT / "data/prints.json").read_text(encoding="utf-8"))["prints"]

sale_images_source = ROOT / "assets" / "sale-corsets"
sale_images_output = ROOT / "dist" / "sale-corsets"
if not sale_images_source.is_dir():
    raise FileNotFoundError(f"Sale corset images are missing: {sale_images_source}")
if sale_images_output.exists():
    shutil.rmtree(sale_images_output)
sale_images_output.mkdir(parents=True, exist_ok=True)
sale_images = sorted(
    (path for path in sale_images_source.iterdir()
     if path.is_file() and path.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp")),
    key=lambda path: path.name.lower(),
)
if not sale_images:
    raise FileNotFoundError(f"No sale corset images found in {sale_images_source}")
for image_path in sale_images:
    shutil.copy2(image_path, sale_images_output / image_path.name)

fabric_images_source = ROOT / "assets" / "fabrics"
fabric_images_output = ROOT / "dist" / "fabrics"
if not fabric_images_source.is_dir():
    raise FileNotFoundError(f"Fabric swatch images are missing: {fabric_images_source}")
if fabric_images_output.exists():
    shutil.rmtree(fabric_images_output)
shutil.copytree(fabric_images_source, fabric_images_output)

home_media_source = ROOT / "assets" / "homepage"
home_media_output = ROOT / "dist" / "homepage-media"
if home_media_output.exists():
    shutil.rmtree(home_media_output)
home_media = {}
video_files = sorted(
    (path for path in home_media_source.glob("*")
     if path.is_file() and path.suffix.lower() in (".mp4", ".webm")
     and (path.stem == "campaign" or (path.stem.startswith("campaign-") and path.stem != "campaign-photo"))),
    key=lambda path: (path.stem != "campaign", path.name.lower()),
)
if video_files:
    home_media_output.mkdir(parents=True, exist_ok=True)
    home_media["videos"] = []
    for media_file in video_files:
        shutil.copy2(media_file, home_media_output / media_file.name)
        home_media["videos"].append(f"homepage-media/{media_file.name}")
    # Keep the original single-video field for compatibility with existing builds.
    home_media["video"] = home_media["videos"][0]

photo_stem, photo_suffixes = "campaign-photo", (".jpg", ".jpeg", ".png", ".webp")
for suffix in photo_suffixes:
    media_file = home_media_source / f"{photo_stem}{suffix}"
    if media_file.is_file():
        home_media_output.mkdir(parents=True, exist_ok=True)
        shutil.copy2(media_file, home_media_output / media_file.name)
        home_media["photo"] = f"homepage-media/{media_file.name}"
        break

# Outfit videos must be explicitly mapped to a stable design ID in designs.json.
# Generic campaign clips are not assigned to designs by filename or list order.
design_videos = {}
for design in designs:
    video_ref = design.get("video")
    if not video_ref:
        continue
    video_source = (ROOT / video_ref).resolve()
    if not video_source.is_file():
        raise FileNotFoundError(f"Design {design['id']} references a missing outfit video: {video_ref}")
    if video_source.suffix.lower() not in (".mp4", ".webm"):
        raise ValueError(f"Design {design['id']} video must be .mp4 or .webm: {video_ref}")
    video_output = home_media_output / "design-videos"
    video_output.mkdir(parents=True, exist_ok=True)
    output_name = f"{design['id']}{video_source.suffix.lower()}"
    shutil.copy2(video_source, video_output / output_name)
    design_videos[design["id"]] = f"homepage-media/design-videos/{output_name}"
if design_videos:
    home_media["designVideos"] = design_videos
else:
    print("No outfit-specific video mappings found; the carousel will show each design image in both panels.")

data = {
    "designs": [
        {"id": d["id"], "name": d["name"], "tagline": d["tagline"],
         "main": uri(ROOT / d["images"]["main"], 420, 78),
         "det": uri(ROOT / d["images"]["details"], 420, 78)}
        for d in designs
    ],
    "prints": [
        {"id": p["id"], "name": p["name"], "tagline": p["tagline"],
         "img": uri(ROOT / p["images"]["swatch"], 150, 80)}
        for p in prints
    ],
    "homeMedia": home_media,
}

html = (ROOT / "src/template.html").read_text(encoding="utf-8").replace(
    "__DATA__", json.dumps(data, ensure_ascii=False))
out = ROOT / "dist" / "index.html"
out.parent.mkdir(exist_ok=True)
out.write_text(html, encoding="utf-8")
print(f"Built {out} ({len(html) // 1024} KB)")
